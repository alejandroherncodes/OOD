package ledger;

public enum ItemType {
  Expense,Income
}
