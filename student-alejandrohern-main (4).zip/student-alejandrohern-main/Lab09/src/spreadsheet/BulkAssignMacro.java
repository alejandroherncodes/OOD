package spreadsheet;

/**
 * This class represents a bulk assignment of a macro to
 * all the cells in a specific range.
 */
public class BulkAssignMacro implements SpreadSheetMacro {
  private final int fromRow;
  private final int fromCol;
  private final int toRow;
  private final int toCol;
  private final double value;

  /**
   * Create a bulk assign macro object given a range based on cell values.
   *
   * @param fromRow                           the row of the first cell in the range
   * @param fromCol                        the column of the first cell in the range
   * @param toRow                              the row of the last cell in the range
   * @param toCol                           the column of the last cell in the range
   * @param value                 the value to be copied into the cells in the range
   */
  public BulkAssignMacro(int fromRow, int fromCol, int toRow, int toCol, double value) throws IllegalArgumentException {
    if (toRow < 0 || toCol < 0 || fromRow < 0 || fromCol < 0) {
      throw new IllegalArgumentException("None of the values can be negative.");
    }

    this.fromRow = fromRow;
    this.fromCol = fromCol;
    this.toRow = toRow;
    this.toCol = toCol;
    this.value = value;
  }

  /**
   * Executes a bulk assignment of a single macro to the given SpreadSheet
   *
   * @param sheet                            the SpreadSheet to execute on
   */
  @Override
  public void execute(SpreadSheet sheet) {
    for (int i = fromRow; i <= toRow; i += 1) {
      for (int j = fromCol; j <= toCol; j += 1) {
        sheet.set(i, j, value);
      }
    }
  }

}