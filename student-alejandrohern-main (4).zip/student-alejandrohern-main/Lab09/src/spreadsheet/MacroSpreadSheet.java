package spreadsheet;

/**
 * This interface represents a singular macro object in a spreadsheet.
 */

public interface MacroSpreadSheet extends SpreadSheet {
  /**
   * Executes the given macro on this spreadsheet.
   *
   * @param macro           a macro to be executed
   */
  void executeMacro(SpreadSheetMacro macro);
}